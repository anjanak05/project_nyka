// var slidebarpics =[
//     {image_url:"https://images-static.nykaa.com/uploads/84aea920-66f9-4b6d-a035-646a938f3cd2.jpg?tr=w-1200,cm-pad_resize"},
//     {image_url: " https://images-static.nykaa.com/uploads/b7858c0d-cb67-4461-9925-9a38a3af9e69.jpg?tr=w-1200,cm-pad_resize"},
//     {image_url: "https://images-static.nykaa.com/uploads/8d82e0b0-0796-4666-b30f-7dd19fff8841.jpg?tr=w-1200,cm-pad_resize" },
//     {image_url: "https://images-static.nykaa.com/uploads/939afd5f-b332-4e91-9879-c5da9ad5b17e.jpg?tr=w-1200,cm-pad_resize "},
//     {image_url:"https://images-static.nykaa.com/uploads/00364ac3-707a-49ec-9eaa-52011fbbb2ac.jpg?tr=w-1200,cm-pad_resize" },

// ];

var brandImages = [
    {
        image_url: "https://images-static.nykaa.com/uploads/b91b3e45-5c94-4f66-90bb-6a082ae3c39c.png?tr=w-300,cm-pad_resize",
        offer: "Minis Starting At ₹299",
    },
    {
        image_url: "https://images-static.nykaa.com/uploads/b77c1aa3-167a-4ecc-8866-b00e9bc9fbdd.png?tr=w-300,cm-pad_resize",
        offer: "Up To 30% Off",
    },
    {
        image_url: "https://images-static.nykaa.com/uploads/36292be3-2d84-4cd5-85b8-8f6f67ec03f3.jpg?tr=w-300,cm-pad_resize",
        offer: "Min 20% Off",
    },

    {
        image_url: "https://images-static.nykaa.com/uploads/7e868ddc-9cab-4459-a49c-c95ac28794f6.jpg?tr=w-300,cm-pad_resize",
        offer: "Up To 20% Off",
    },


    {
        image_url: "https://images-static.nykaa.com/uploads/dddb8935-238f-425c-b299-a5a84116e098.jpg?tr=w-300,cm-pad_resize",
        offer: "Up To 50% Off",
    },

    
    {
        image_url: "https://images-static.nykaa.com/uploads/1a59123c-bd4a-4241-99ba-0e37785c2709.jpg?tr=w-300,cm-pad_resize",
        offer: "Free Eyeliner On ₹499"
    },
    {
        image_url: "https://images-static.nykaa.com/uploads/5570991d-0094-4408-a22a-4dfd43d9b3c7.jpg?tr=w-300,cm-pad_resize",
        offer: "Minis Starting At ₹299",
    },
    
    {
        image_url: "https://images-static.nykaa.com/uploads/71ed5bd7-0f5b-4f75-a339-2e3e79c1c79a.jpg?tr=w-300,cm-pad_resize",
        offer: "Free Eyeliner On ₹499+",
    }


];
var vr = localStorage.setItem("brandImagesData", JSON.stringify(brandImages));
