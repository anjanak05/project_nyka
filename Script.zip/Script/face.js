JSON.parse(localStorage.getItem("faceProductsImagesData"));
var faceProductsImages = JSON.parse(localStorage.getItem("faceProductsImagesData")) || [];

faceProductsImages.map(function (elem, index) {
    var faceDiv = document.createElement("div")
    var priceDiv = document.createElement("div");
    var bagDiv = document.createElement("div");
    
    priceDiv.setAttribute("class", "priceSection")

    var image = document.createElement("img")
    image.setAttribute("src", elem.image_url)

    var title = document.createElement("p")
    title.innerText = elem.title;

    var strikedOffprice = document.createElement("p")
    strikedOffprice.innerText = elem.strikedOffprice;
    strikedOffprice.style.textDecoration="line-through"

    var price = document.createElement("p")
    price.innerText = elem.price;

    var button = document.createElement("button")
    button.innerText="Add To Bag"
     
    var likeImage = document.createElement("img")
    likeImage.setAttribute("src", '<i class="fa-thin fa-heart"></i>')
    
    bagDiv.append(likeImage, button)
    
    priceDiv.append(strikedOffprice, price)
    faceDiv.append(image, title, priceDiv, bagDiv);
    document.querySelector(".products").append( faceDiv)

})

localStorage.setItem("faceProductsImagesData", JSON.stringify(faceProductsImages));