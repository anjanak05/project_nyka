
 
var data = JSON.parse(localStorage.getItem("brandImagesData"));


data.map(function(elem, index){
var logoDiv = document.createElement("div");
 
var logoimages= document.createElement("img");
logoimages.setAttribute("src", elem.image_url);
logoimages.setAttribute("class", "logoimages")

logoDiv.append(logoimages);
document.querySelector(".logo ").append(logoDiv);



})


localStorage.setItem("brandImagesData", JSON.stringify(brandImagesData));

